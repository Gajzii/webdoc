/* Play/Pause HTML Video Based on Visibility / event listener/ hvem er vi video*/
var vid = document.getElementById("hvemervivideo");
vid.loop = true;
var hvemervisektion = document.getElementById("hvemervivideo");
document.addEventListener("scroll", function myFunction() {
  if (
    hvemervisektion.getBoundingClientRect().bottom < 400 ||
    hvemervisektion.getBoundingClientRect().top > 300
  )
    hvemervisektion.pause();
  else hvemervisektion.play();
});
/* Play/Pause HTML Video Based on Visibility / event listener/ hvem er du video  */
var vid = document.getElementById("hvemerduvideo");
vid.loop = true;
var hvemerdusektion = document.getElementById("hvemerduvideo");
document.addEventListener("scroll", function myFunction() {
  if (
    hvemerdusektion.getBoundingClientRect().bottom < 400 ||
    hvemerdusektion.getBoundingClientRect().top > 400
  )
    hvemerdusektion.pause();
  else hvemerdusektion.play();
});
/* ---------- talebobbel TYPEWRITER EFFEKT med erase funktion---------- */
const typedTextSpan = document.querySelector(".typed-text");
const cursorSpan = document.querySelector(".cursor");
/*definere variabler til typewriter effekten i taleboble*/
const textArray = [
  "Det bedste ved Toft Digital er at det er et startup, og dermed en lille virksomhed så man føler at man bliver set. ",
  "Jeg føler selv at jeg har udviklet mig her hos Toft Digital. Jeg har lært at tage ansvar og træffe vigtige beslutninger. ",
  "Jeg vil helt klart anbefale andre at søge praktik hos Toft Digital hvis de vil noget med deres liv. ",
  "Det er meget anderledes at være i praktik hos et startup, det kan tydeligt mærkes at der er langt mere frihed under ansvar. ",
];
const typingDelay = 80; //Delay before typing the next character
const erasingDelay = 80; //Delay to start writing text
const newTextDelay = 4000; // Delay between current and next text
let textArrayIndex = 0;
let charIndex = 0;
/*typing funktion*/
function type() {
  if (charIndex < textArray[textArrayIndex].length) {
    if (!cursorSpan.classList.contains("typing"))
      cursorSpan.classList.add("typing");
    typedTextSpan.textContent += textArray[textArrayIndex].charAt(charIndex);
    charIndex++;
    setTimeout(type, typingDelay);
  } else {
    cursorSpan.classList.remove("typing");
    setTimeout(erase, newTextDelay);
  }
}
/*erase typing funktion*/
function erase() {
  if (charIndex > 0) {
    if (!cursorSpan.classList.contains("typing"))
      cursorSpan.classList.add("typing");
    typedTextSpan.textContent = textArray[textArrayIndex].substring(
      0,
      charIndex - 1
    );
    charIndex--;
    setTimeout(erase, erasingDelay);
  } else {
    cursorSpan.classList.remove("typing");
    textArrayIndex++;
    if (textArrayIndex >= textArray.length) textArrayIndex = 0;
    setTimeout(type, typingDelay + 800);
  }
}
/* Når contentet i DOM er loadet starter funktion typewriter effekten  */
document.addEventListener("DOMContentLoaded", function () {
  // On DOM Load initiate the effect
  if (textArray.length) setTimeout(type, newTextDelay + 250);
});
/* ---------------------------------- */
/* -------- parallax baggrund ------- */
window.addEventListener("scroll", function () {
  var scrollPosition = window.pageYOffset;
  var bgParallax = document.getElementsByClassName("parallax")[0];
  var limit = bgParallax.offsetTop + bgParallax.offsetHeight;
  if (scrollPosition > bgParallax.offsetTop && scrollPosition <= limit) {
    bgParallax.style.backgroundPositionY = scrollPosition / 6 + "px";
  } else {
    bgParallax.style.backgroundPositionY = "0";
  }
});
